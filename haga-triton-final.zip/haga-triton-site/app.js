// ═══════════════════════════════════════════════
// HAGA TRITON — APP
// ═══════════════════════════════════════════════

// Hash SHA-256 du mot de passe opérateur (jamais en clair dans le code)
const OPERATOR_HASH = "95d624dc6013b6507a6ef9f062285be4f43858407e3a072bc778dca769a3530b";

let supa = null;
let isOperator = false;
let clones = [];

const INITIAL_CLONES = [
  {code:'CLN-001',nom:'Bulbizarre',type:'Plante / Poison',note:'Clone parfait — aucune déviation génétique détectée.'},
  {code:'CLN-002',nom:'Salamèche',type:'Feu',note:'Flamme caudale identique à l\'original. Comportement stable.'},
  {code:'CLN-003',nom:'Carapuce',type:'Eau',note:'Carapace conforme. Aucune anomalie détectée.'},
  {code:'CLN-004',nom:'Goinfrex',type:'Normal',note:'Séquence complète — comportement alimentaire normal.'},
  {code:'CLN-005',nom:'Dardargnan',type:'Insecte / Poison',note:'Aiguillon conforme. Intégrité parfaite.'},
  {code:'CLN-006',nom:'Ténéfix',type:'Ténèbres',note:'Clone stable. Synchronisation gènes obscurs réussie.'},
  {code:'CLN-007',nom:'Pikachu',type:'Électrik',note:'Clonage électrique parfait — aucune fluctuation.'},
];

const SLOT_LABELS = {corps:'SCAN CORPS', tete:'TÊTE / VISAGE', bras:'MEMBRES', queue:'DÉTAIL'};

// ═══ CLOCK ═══
setInterval(()=>{
  const el = document.getElementById('clock');
  if(el) el.textContent = new Date().toLocaleTimeString('fr-FR');
},1000);

// ═══ SHA-256 ═══
async function sha256(str){
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

// ═══ OPERATOR MODE ═══
function toggleOperator(){
  if(isOperator){
    isOperator = false;
    sessionStorage.removeItem('haga_op');
    updateOperatorUI();
  } else {
    document.getElementById('modal-pass').style.display='flex';
    setTimeout(()=>document.getElementById('f-pass').focus(),100);
  }
}

async function checkPassword(){
  const val = document.getElementById('f-pass').value;
  const hash = await sha256(val);
  if(hash === OPERATOR_HASH){
    isOperator = true;
    sessionStorage.setItem('haga_op','1');
    closePassModal();
    updateOperatorUI();
  } else {
    document.getElementById('pass-error').style.display='block';
    setTimeout(()=>{ document.getElementById('pass-error').style.display='none'; },2500);
  }
}

function closePassModal(){
  document.getElementById('modal-pass').style.display='none';
  document.getElementById('f-pass').value='';
  document.getElementById('pass-error').style.display='none';
}

function updateOperatorUI(){
  const btn = document.getElementById('btn-op');
  const icon = document.getElementById('op-icon');
  const label = document.getElementById('op-label');
  const status = document.getElementById('sec-status');
  document.querySelectorAll('.op-only').forEach(el=>{
    el.style.display = isOperator ? '' : 'none';
  });
  if(isOperator){
    btn.classList.add('active');
    icon.textContent='🔓';
    label.textContent='OPÉRATEUR ACTIF';
    if(status) status.textContent='Mode opérateur — vous pouvez modifier le registre';
  } else {
    btn.classList.remove('active');
    icon.textContent='🔒';
    label.textContent='MODE OPÉRATEUR';
    if(status) status.textContent='Consultation publique — mode opérateur requis pour modifier';
  }
}

// ═══ SUPABASE ═══
function initSupabase(){
  if(typeof SUPABASE_URL==='undefined' || SUPABASE_URL.includes('COLLE_TON')){
    document.getElementById('clone-grid').innerHTML =
      '<div class="loading">⚠ Configuration Supabase manquante — voir GUIDE-INSTALLATION.md</div>';
    return false;
  }
  supa = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  return true;
}

async function fetchClones(){
  const {data, error} = await supa.from('clones').select('*').order('code');
  if(error){ console.error(error); return []; }
  return data || [];
}

async function seedIfEmpty(){
  const existing = await fetchClones();
  if(existing.length === 0){
    await supa.from('clones').insert(INITIAL_CLONES);
    return fetchClones();
  }
  return existing;
}

async function uploadImage(file, cloneCode, slot){
  const ext = file.name.split('.').pop() || 'png';
  const path = `${cloneCode}/${slot}.${ext}`;
  const {error} = await supa.storage.from('clone-images').upload(path, file, {upsert:true});
  if(error){ alert('Erreur upload : '+error.message); return null; }
  const {data} = supa.storage.from('clone-images').getPublicUrl(path);
  const url = data.publicUrl + '?t=' + Date.now();

  const col = 'img_'+slot;
  await supa.from('clones').update({[col]: url}).eq('code', cloneCode);
  return url;
}

// ═══ ECG CANVAS ═══
function drawECG(canvas, seed){
  const ctx = canvas.getContext('2d');
  const W = canvas.width = canvas.offsetWidth||300;
  const H = canvas.height = 28;
  ctx.fillStyle='#0E1120'; ctx.fillRect(0,0,W,H);
  ctx.beginPath(); ctx.strokeStyle='#1AE050'; ctx.lineWidth=1; ctx.globalAlpha=0.85;
  let x=0, y=H/2;
  ctx.moveTo(0,y);
  for(let i=0;i<Math.floor(W/3);i++){
    const mod = (i*3 + seed*17) % 60;
    if(mod<5) y=H/2;
    else if(mod===6) y=H*0.15;
    else if(mod===9) y=H*0.85;
    else if(mod===12) y=H*0.1;
    else if(mod<16) y=H/2;
    else y=H/2 + Math.sin(i*0.3)*2;
    ctx.lineTo(x,y); x+=3;
  }
  ctx.stroke(); ctx.globalAlpha=1;
}

function bodySVG(){
  return `<svg viewBox="0 0 60 100" xmlns="http://www.w3.org/2000/svg" opacity="0.5">
    <ellipse cx="30" cy="14" rx="11" ry="13" fill="none" stroke="#00D4FF" stroke-width="1.2"/>
    <rect x="18" y="26" width="24" height="32" rx="4" fill="none" stroke="#00D4FF" stroke-width="1.2"/>
    <line x1="18" y1="28" x2="6" y2="52" stroke="#00D4FF" stroke-width="1.2" stroke-linecap="round"/>
    <line x1="42" y1="28" x2="54" y2="52" stroke="#00D4FF" stroke-width="1.2" stroke-linecap="round"/>
    <line x1="24" y1="58" x2="20" y2="96" stroke="#00D4FF" stroke-width="1.2" stroke-linecap="round"/>
    <line x1="36" y1="58" x2="40" y2="96" stroke="#00D4FF" stroke-width="1.2" stroke-linecap="round"/>
  </svg>`;
}

// ═══ RENDER ═══
function renderCard(c){
  const card = document.createElement('div');
  card.className='card';
  const seed = parseInt(c.code.replace(/\D/g,''))||1;

  const corpsContent = c.img_corps
    ? `<img src="${c.img_corps}" class="body-img"/>`
    : `<div class="body-slot-placeholder">${bodySVG()}<span>SILHOUETTE</span></div>`;

  const partHTML = (slot, label) => {
    const img = c['img_'+slot];
    return `
    <div class="part-panel">
      <div class="part-label">${label}</div>
      ${img ? `<img src="${img}" class="part-img"/>` : `<div class="part-placeholder">—</div>`}
      <input type="file" class="file-hidden" id="file-${c.code}-${slot}" accept="image/*"/>
      <button class="part-upload op-only" style="display:${isOperator?'':'none'}" onclick="document.getElementById('file-${c.code}-${slot}').click()">⊕</button>
    </div>`;
  };

  card.innerHTML = `
    <div class="card-hud-corner"><span>HUD</span></div>
    <div class="card-inner">
      <div class="card-top">
        <div class="body-panel">
          <div class="body-panel-top">SCAN CORPS</div>
          <div class="body-slot">
            ${corpsContent}
            <div class="body-scan-line"></div>
            <input type="file" class="file-hidden" id="file-${c.code}-corps" accept="image/*"/>
          </div>
          <button class="body-upload-btn op-only" style="display:${isOperator?'':'none'}" onclick="document.getElementById('file-${c.code}-corps').click()">⊕ IMAGE</button>
        </div>
        <div class="card-data">
          <div class="card-id">${c.code}</div>
          <div class="card-name">${c.nom}</div>
          <div class="card-type">TYPE : ${c.type||'—'}</div>
          <div class="badge-ok">✓ STABLE — ADN 100%</div>
          <div class="card-stats">
            <div class="stat-row"><span class="stat-key">ADN</span><div class="stat-track"><div class="stat-bar" style="width:100%"></div></div><span class="stat-val">100%</span></div>
            <div class="stat-row"><span class="stat-key">STABILITÉ</span><div class="stat-track"><div class="stat-bar" style="width:100%"></div></div><span class="stat-val">100%</span></div>
            <div class="stat-row"><span class="stat-key">VITALITÉ</span><div class="stat-track"><div class="stat-bar" style="width:95%"></div></div><span class="stat-val">95%</span></div>
          </div>
        </div>
      </div>
      <div class="detail-parts">
        ${partHTML('tete','TÊTE / VISAGE')}
        ${partHTML('bras','MEMBRES')}
        ${partHTML('queue','DÉTAIL')}
      </div>
      <div class="ecg"><canvas></canvas><span class="ecg-label">VITAL — NOMINAL</span></div>
    </div>
    ${c.note?`<div class="card-note">${c.note}</div>`:''}
  `;

  // ECG
  requestAnimationFrame(()=>{
    const cv = card.querySelector('.ecg canvas');
    if(cv) drawECG(cv, seed);
  });

  // File handlers
  ['corps','tete','bras','queue'].forEach(slot=>{
    const input = card.querySelector(`#file-${c.code}-${slot}`);
    if(input){
      input.addEventListener('change', async (e)=>{
        const file = e.target.files[0];
        if(!file) return;
        if(!isOperator){ alert('Mode opérateur requis'); return; }
        const url = await uploadImage(file, c.code, slot);
        if(url){
          c['img_'+slot] = url;
          await renderAll();
          addLogUI('IMAGE', `${c.code} — slot ${slot.toUpperCase()} mis à jour`, 's');
        }
      });
    }
  });

  return card;
}

async function renderAll(){
  const grid = document.getElementById('clone-grid');
  grid.innerHTML='';
  clones.forEach(c=>grid.appendChild(renderCard(c)));
  document.getElementById('chip-total').textContent = 'CLONES : '+clones.length;
  updateOperatorUI();
}

// ═══ LOGS (locaux, visuels) ═══
const LOGS_INIT = [
  {time:'00:00:01',cat:'SYSTÈME',msg:'Initialisation HAGA TRITON MK.III — démarrage nominal',t:'s'},
  {time:'00:00:04',cat:'ADN',msg:'Connexion séquence Mew — MEWTWO en phase embryonnaire',t:'s'},
  {time:'02:14:33',cat:'ALERTE',msg:'Niveau ROUGE détecté dans la cuve — intervention requise',t:'e'},
  {time:'02:15:10',cat:'SYSTÈME',msg:'Stabilisation — Dr. Estra, protocole d\'urgence actif',t:'w'},
  {time:'21:00:00',cat:'MEWTWO',msg:'Sujet sorti de cuve — armure installée, surveillance active',t:'w'},
];
let logs = [...LOGS_INIT];

function addLogUI(cat,msg,t=''){
  logs.push({time:new Date().toTimeString().slice(0,8),cat,msg,t});
  renderLogs();
}
function renderLogs(){
  const body = document.getElementById('log-body');
  if(!body) return;
  body.innerHTML = logs.slice(-15).reverse().map(l=>`
    <div class="log-row">
      <div class="log-cell">${l.time}</div>
      <div class="log-cell">${l.cat}</div>
      <div class="log-cell ${l.t}">${l.msg}</div>
    </div>`).join('');
}

// ═══ MODAL CLONE ═══
function openModal(){
  if(!isOperator){ alert('Mode opérateur requis'); return; }
  document.getElementById('modal-clone').style.display='flex';
}
function closeCloneModal(){
  document.getElementById('modal-clone').style.display='none';
  ['f-nom','f-type','f-note'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
}

async function addClone(){
  const nom = document.getElementById('f-nom').value.trim();
  const type = document.getElementById('f-type').value.trim()||'Inconnu';
  const note = document.getElementById('f-note').value.trim();
  if(!nom) return;
  const maxNum = Math.max(0,...clones.map(c=>parseInt(c.code.replace('CLN-',''))||0));
  const code = 'CLN-'+String(maxNum+1).padStart(3,'0');
  const {error} = await supa.from('clones').insert({code,nom,type,note});
  if(error){ alert('Erreur : '+error.message); return; }
  clones = await fetchClones();
  await renderAll();
  addLogUI('CLONAGE', `${code} ${nom.toUpperCase()} — ADN 100% — STABLE`, 's');
  closeCloneModal();
}

// Modal close on overlay click
document.getElementById('modal-pass').addEventListener('click',e=>{if(e.target.id==='modal-pass')closePassModal();});
document.getElementById('modal-clone').addEventListener('click',e=>{if(e.target.id==='modal-clone')closeCloneModal();});

// ═══ INIT ═══
async function init(){
  if(sessionStorage.getItem('haga_op')==='1') isOperator=true;
  renderLogs();
  if(!initSupabase()) return;
  try{
    clones = await seedIfEmpty();
    clones.forEach(c=>{
      addLogUI('CLONAGE', `${c.code} ${c.nom.toUpperCase()} — ADN 100% — STABLE`, 's');
    });
    await renderAll();
  }catch(err){
    document.getElementById('clone-grid').innerHTML =
      '<div class="loading">⚠ Erreur de connexion Supabase — vérifie config.js et le guide</div>';
    console.error(err);
  }
}

init();
