// ═══════════════════════════════════════════════
// CONFIGURATION SUPABASE
// ═══════════════════════════════════════════════

const SUPABASE_URL = "https://ncscyuojeehypjszcgul.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5jc2N5dW9qZWVoeXBqc3pjZ3VsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODMxODIyMDQsImV4cCI6MjA5ODc1ODIwNH0.HbrF5vLIQKMA0vVbAxs9HwpjDUf6ySekg4f8_gJmvo4";
